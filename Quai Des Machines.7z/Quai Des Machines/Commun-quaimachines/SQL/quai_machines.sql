-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Mar 08 Mars 2016 à 15:14
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `quai_machines`
--

-- --------------------------------------------------------

--
-- Structure de la table `evenement`
--

CREATE TABLE IF NOT EXISTS `evenement` (
  `ID_EVENEMENT` int(11) NOT NULL AUTO_INCREMENT,
  `NOM_EVENEMENT` varchar(255) NOT NULL,
  `DESCRIPTION_EVENEMENT` longtext NOT NULL,
  `DATE_EVENEMENT` date NOT NULL,
  PRIMARY KEY (`ID_EVENEMENT`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `evenement`
--

INSERT INTO `evenement` (`ID_EVENEMENT`, `NOM_EVENEMENT`, `DESCRIPTION_EVENEMENT`, `DATE_EVENEMENT`) VALUES
(1, 'Mexicaine', 'Semaine Merxicaine, peperonni, plats chorizo....', '2016-03-10'),
(2, 'Semaine Chinoise', 'udhauhfdaf bfibgiezf fzgfig zhfzeughfuigfizzi hezfigzig ohizfh ', '2016-03-17');

-- --------------------------------------------------------

--
-- Structure de la table `newsletter`
--

CREATE TABLE IF NOT EXISTS `newsletter` (
  `ID_NEWSLETTER` int(11) NOT NULL AUTO_INCREMENT,
  `MAIL` varchar(255) DEFAULT NULL,
  `TOKEN` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`ID_NEWSLETTER`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `newsletter`
--

INSERT INTO `newsletter` (`ID_NEWSLETTER`, `MAIL`, `TOKEN`) VALUES
(1, 'fistiniere@malofion.fr', '0TQcnGt8eShNI9lCJTH1uwaJtbgmxh3QXmj24UaTvYyxxjENmvNd7W42L4om'),
(2, 'fistiniere@malofion.fr', 'xW1kxFCKgTXMgVC65rp1jVX919gLAgy6JUmaPoOHiylek1HLxCK6QOGDYet7'),
(3, 'sans@avatar.com', NULL),
(4, 'antoine@free.fr', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `semaine`
--

CREATE TABLE IF NOT EXISTS `semaine` (
  `ID_SEMAINE` int(11) NOT NULL AUTO_INCREMENT,
  `LUNDI` varchar(255) DEFAULT NULL,
  `MARDI` varchar(255) DEFAULT NULL,
  `MERCREDI` varchar(255) DEFAULT NULL,
  `JEUDI` varchar(255) DEFAULT NULL,
  `VENDREDI` varchar(255) DEFAULT NULL,
  `SAMEDI` varchar(255) DEFAULT NULL,
  `DIMANCHE` varchar(255) DEFAULT NULL,
  `NUM_SEMAINE` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID_SEMAINE`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `semaine`
--

INSERT INTO `semaine` (`ID_SEMAINE`, `LUNDI`, `MARDI`, `MERCREDI`, `JEUDI`, `VENDREDI`, `SAMEDI`, `DIMANCHE`, `NUM_SEMAINE`) VALUES
(1, 'hfvjaezvFJ', 'HDVJVCFHJV', 'BDBDdgezd', 'gdugdg', 'gudfazgfig', 'dugigg', 'gdfugzfeizg', 9),
(2, 'hfvjaezvFJ', 'HDVJVCFHJV', 'BDBDdgezd', 'gdugdg', 'gudfazgfig', 'dugigg', 'gdfugzfeizg', 9),
(3, 'adsazBBBBBBBBB', 'dfaqezf', 'hjv', 'juv', 'hjv', 'v', 'dfezuvf', 10),
(4, 'doner', 'kebab', 'frites', 'choucroute', 'couscous', 'weight watchers', 'buffet a volonté', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
