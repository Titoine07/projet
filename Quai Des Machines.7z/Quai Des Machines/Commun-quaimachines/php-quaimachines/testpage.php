<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php

            echo "Weeknumber : ".date("W")."<br/>";

            echo " Monday from Weeknumber : ".date("M d", strtotime("2016W09"))."<br/>";
            echo " Sunday from Weeknumber : ".date("M d", strtotime("2016W09 + 6 days"))."<br/>";

            echo "<br/><a href='unittests/weekmealsplanning.php'>See Year's Week Planning</a><br/>";

            echo "<br/><a href='unittests/events.php'>Events</a><br/>";

            echo "<br/><a href='unittests/newsletter.php'>Test Newsletter</a><br/>";
            echo "<br/><a href='index.php'>Return to Index Page</a><br/>";
        ?>
    </body>
</html>
