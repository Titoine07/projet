<?php


class NewsletterController
{

    private $_newsletterManager;

    public function __construct() {
        $this->_newsletterManager = new NewsletterManager(PDOFactory::getConnection());
    }


    public function mailOperations($mail){

        if (isset($mail)) {
            // Nettoyage balises HTML que le visiteur a pu rentrer
            $mail = htmlspecialchars($mail);
        }

        // Verif Email
        if (!preg_match("#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#", $mail)) {
            echo "Invalid Email";
            return;
        }

        // Check $mail($_POST['mail'] = existe dans la base ($bddMail)
        $bddMail = $this->_newsletterManager->mailCheck($mail);

        if($mail == $bddMail){
            echo "Email déja pris"; // Email déja existant
            return;
        }

        // Generation du token
        $token = $this->_newsletterManager->strRandom(60);
        // Enregistrement dans la bdd
        $this->_newsletterManager->mailSave($mail, $token);
        // Recup Last ID DB Record
        $lastId = $this->_newsletterManager->getLast();
        // Generation du mail de confirmation contenant le lien de desinscription
        mail($mail, 'Confirmation de insription à la newsletter "Le Quai Des Machines"' , "Pour vous désinscrire cliquez ici: http://localhost/gil/Quai Des Machines/Commun-quaimachines/php-quaimachines/unsubscribe.php?id=".$lastId."&token=$token");
        // msg success
        echo "Inscription effectuée avec succès!";
    }


    public function unsubscribe($id, $token){

        if($match = $this->_newsletterManager->verifyUnsubscribe($id, $token)){

            $this->_newsletterManager->resetToken($id, $token);
            echo "Vous êtes désabonné";

        } else {

            echo "Token Invalide";
        }
    }
}