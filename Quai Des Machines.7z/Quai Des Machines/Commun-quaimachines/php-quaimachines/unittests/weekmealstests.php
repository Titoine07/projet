<?php
    if(!empty($_GET['id'])){
        echo 'Vous allez créer les repas de la semaine '.$_GET['id'];
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <form action="" method="post" id="createform">
            <p>Créer les plats du jour de la semaine :</p>
            <label>Lundi : </label>
            <input type='text' maxlength=255 name='lundi'/><br/>
            <label>Mardi : </label>
            <input type='text' maxlength=255 name='mardi'/><br/>
            <label>Mercredi : </label>
            <input type='text' maxlength=255 name='mercredi'/><br/>
            <label>Jeudi : </label>
            <input type='text' maxlength=255 name='jeudi'/><br/>
            <label>Vendredi : </label>
            <input type='text' maxlength=255 name='vendredi'/><br/>
            <label>Samedi : </label>
            <input type='text' maxlength=255 name='samedi'/><br/>
            <label>Dimanche : </label>
            <input type='text' maxlength=255 name='dimanche'/><br/>
            <input type="hidden" name="numSemaine" value="<?php echo $_GET['id'];?>">
            <input type="submit" name="submitCreate" value="Créer Semaine"/>
        </form>
        <?php
            require_once '../lib/lib.php';
            spl_autoload_register(function ($class) {
                include '../' . $class . '.class.php';
            });

            $ctrl = new WeekMealsController();
            
            if (isset($_POST['submitCreate'])) {

                $ctrl->createNextWeekMeals(array($_POST['lundi'],
                                                 $_POST['mardi'],
                                                 $_POST['mercredi'],
                                                 $_POST['jeudi'],
                                                 $_POST['vendredi'],
                                                 $_POST['samedi'],
                                                 $_POST['dimanche'],
                                                 $_POST['numSemaine']));
                echo "Request submitted !";
            }
        ?>

        <a href='../testpage.php'>Return to Test Page</a><br/>
        <a href='../index.php'>Return to Index Page</a>


    </body>
</html>