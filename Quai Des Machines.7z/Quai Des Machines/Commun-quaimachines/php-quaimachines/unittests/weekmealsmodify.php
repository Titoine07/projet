<?php
    require_once '../lib/lib.php';
    spl_autoload_register(function ($class) {
        include '../' . $class . '.class.php';
    });

$plats = new WeekMealsController();
$data = $plats->getWeekMealsById($_GET['id']);

?>


<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <form action="?ctrl=weekmeals&action=create" method="post" id="createform">
            <p>Modifier les plats du jour de la semaine en cours(Semaine <?php echo $data->NUM_SEMAINE ?>) :</p>
            <input type='hidden' name='semaine' value="<?php echo $data->NUM_SEMAINE ?>" /><br/>
            <label>Lundi : </label>
            <input type='text' maxlength=255 name='lundi' value="<?php echo $data->LUNDI ?>" /><br/>
            <label>Mardi : </label>
            <input type='text' maxlength=255 name='mardi' value="<?php echo $data->MARDI ?>" /><br/>
            <label>Mercredi : </label>
            <input type='text' maxlength=255 name='mercredi' value="<?php echo $data->MERCREDI ?>" /><br/>
            <label>Jeudi : </label>
            <input type='text' maxlength=255 name='jeudi' value="<?php echo $data->JEUDI ?>" /><br/>
            <label>Vendredi : </label>
            <input type='text' maxlength=255 name='vendredi' value="<?php echo $data->VENDREDI ?>" /><br/>
            <label>Samedi : </label>
            <input type='text' maxlength=255 name='samedi' value="<?php echo $data->SAMEDI ?>" /><br/>
            <label>Dimanche : </label>
            <input type='text' maxlength=255 name='dimanche' value="<?php echo $data->DIMANCHE ?>" /><br/>
            <input type="submit" name="submitCreate" value="Modifier Semaine"/>
        </form>
        <?php

            if (isset($_POST['submitCreate'])) {
                $ctrl = new WeekMealsController();
                $ctrl->updateWeekMeals(array($_POST['lundi'],
                                                 $_POST['mardi'],
                                                 $_POST['mercredi'],
                                                 $_POST['jeudi'],
                                                 $_POST['vendredi'],
                                                 $_POST['samedi'],
                                                 $_POST['dimanche'],
                                                 $_POST['semaine']));

                echo "Modification submitted !";
            }
        ?>

        <a href='../testpage.php'>Return to Test Page</a><br/>
        <a href='../index.php'>Return to Index Page</a>

    </body>
</html>
