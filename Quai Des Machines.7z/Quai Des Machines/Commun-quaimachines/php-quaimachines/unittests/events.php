<div align="center" style="width: 600px">
<h1>Upcoming Events</h1>
<?php
require_once '../lib/lib.php';
spl_autoload_register(function ($class) {
    include '../' . $class . '.class.php';
});

$events = new EventsController();
$data = $events->getUpcomingEvents();

foreach($data as $upcoming){
    echo "<div style='background-color: lightgray; width:500px; '>
            <h2>".$upcoming->NOM_EVENEMENT." | ".$upcoming->DATE_EVENEMENT."</h2>
            <p>".$upcoming->DESCRIPTION_EVENEMENT."</p>
            <a href='?action=delete&id=".$upcoming->ID_EVENEMENT."''>Delete</a>
          </div>";
}

if(isset($GET['action']) || ($GET['action'] =='delete')){

    $events->deleteEvent($_GET['id']);
}
?>
<form id="event" action="" method="post">
    <fieldset style="width:500px;">
        <legend>Enter New Event:</legend>
        <br><label for="eventName">Event name:</label>
        <input type="text" name="eventName" placeholder="Event Name"><br>

        <br><label for="dateEvent">Event date:</label>
        <input type="date" name="dateEvent"><br>

        <br><label for="eventDescription">Event description:</label>
        <textarea form="event" id="eventDescription" rows="8" name="eventDescription" placeholder="Type here..."></textarea>

        <br><input type="submit" name="submit" value="Submit">
    </fieldset>
</form>
    <a href='../testpage.php'>Return to Test Page</a><br/>
    <a href='../index.php'>Return to Index Page</a>
</div>
<?php if(isset($_POST['submit'])) {

    if((!empty($_POST['eventName'])) || (!empty($_POST['dateEvent'])) || (!empty($_POST['eventDescription'])) ){

        $addEvent = new EventsController();

        $addEvent->saveEvent(($_POST['eventName']), ($_POST['eventDescription']), ($_POST['dateEvent']));
        echo "Event Added";

    } else {

        echo "Please fill all the fields";
    }
}
?>