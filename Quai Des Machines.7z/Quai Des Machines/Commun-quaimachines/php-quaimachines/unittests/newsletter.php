<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title></title>
</head>
<body>
<form action="" method="post" id="createform">
    <p>Subscribe Newsletter:</p>
    <label for="mail">Mail</label>
    <input id="mail" type='email' name='mail'/><br/>
    <br/><input type="submit" name="submit" value="Subscribe"/>
</form>
<br/><a href='index.php'>Return to Index Page</a>
<?php
    if(!empty($_POST['mail'])){

        require_once '../lib/lib.php';
        spl_autoload_register(function ($class) {
            include '../' . $class . '.class.php';
        });
        $ctrl = new newsletterController();
        $check = $ctrl->mailOperations($_POST['mail']);
    }
?>
