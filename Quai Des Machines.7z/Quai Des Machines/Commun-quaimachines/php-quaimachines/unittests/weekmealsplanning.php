<div align="center">

    <fieldset style="width: 500px; background-color: lightgray">
    <h1>Planning Annuel</h1>

    <table>
        <h2>Liste des semaines</h2>

        <?php
        require_once '../lib/lib.php';
        spl_autoload_register(function ($class) {
            include '../' . $class . '.class.php';
        });
        // Recup des num de semaines deja dans la base
        $ctrl = new WeekMealsController();
        $numbers = $ctrl->getweekNumbers();

        //var_dump($numbers);

        //Generation de la liste des semaines (lundi au dimanche)
        for ($i = 1; $i < 53; $i++) {

            $weeknumber = ($i < 10) ? '0'.$i : $i;
            $str = '2016W'.$weeknumber;
            echo "<tr>
                  <td>Semaine ".$weeknumber."</td>";
            echo "<td>".date("d M", strtotime($str))." - ";
            echo "".date("d M", strtotime($str.' + 6 days'))."</td>";

            if(in_array($weeknumber, $numbers)){

                echo '<td><a href="weekmealsmodify.php?id='.$weeknumber.'">Modify</a></td></tr>';

            } else {

                echo '<td><a href="weekmealstests.php?id='.$weeknumber.'">Create</a></td></tr>';
            }
        }
        ?>
    </table>

    <a href='../index.php'>Return to Index Page</a>
    </fieldset>
</div>