<?php

require_once 'lib/lib.php';
spl_autoload_register(function ($class) {
    include '' . $class . '.class.php';
});

if(isset($_GET['id']) && isset($_GET['token'])){


    // Verif si les $_GET ID_USER & RESET TOKEN existent dans la base
    $verify = new NewsletterController();
    $check = $verify->unsubscribe(($_GET['id']), $_GET['token']);


} else {
    echo "Ce token n'existe pas";
    exit();
}
